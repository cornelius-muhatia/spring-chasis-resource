package com.cm.projects.spring.resource.chasis.wrappers;

public interface Status<T> {

    void setId(T id);
}
