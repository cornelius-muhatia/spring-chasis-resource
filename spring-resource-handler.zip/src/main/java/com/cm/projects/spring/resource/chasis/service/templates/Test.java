package com.cm.projects.spring.resource.chasis.service.templates;

/**
 * @author Cornelius M.
 * @version 1.0.0
 */
public class Test {
}
